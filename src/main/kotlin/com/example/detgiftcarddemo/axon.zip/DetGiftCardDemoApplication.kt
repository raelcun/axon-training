package com.example.detgiftcarddemo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DetGiftCardDemoApplication

fun main(args: Array<String>) {
	runApplication<DetGiftCardDemoApplication>(*args)
}
